"""Record terminal checks, archive maintenance inputs, and retire own scratch."""
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location('compact_close',HERE/'compact.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
REPORT=ROOT/'docs/evidence/compact-repository-20261119.json'
BUNDLE=ROOT/'docs/evidence/compact-repository-20261119-records.tar.gz'
def read(name):return json.loads((HERE/name).read_text())
def services():
 result=[]
 for launch in sorted(HERE.glob('*-launch.json')):
  base=launch.name[:-len('-launch.json')];record=json.loads(launch.read_text());status=read(base+'-status.json')
  assert status['state'] in ('passed','failed','terminated'),base
  properties=subprocess.check_output(['systemctl','--user','show',record['unit'],'-p','MainPID',
     '-p','ControlGroup','-p','ActiveState','-p','SubState','-p','Result','-p','ExecMainStatus'],text=True)
  assert 'MainPID=0\n' in properties and 'ControlGroup=\n' in properties,(base,properties)
  for row in status['descendant_identities']:
   p=Path('/proc')/str(row['pid'])/'stat'
   assert not p.exists() or int(p.read_text().rsplit(')',1)[1].split()[19])!=row['start_ticks']
  result.append(dict(unit=record['unit'],status=status,properties=properties,all_recorded_descendants_terminal=True))
 return result
def record():
 assert not REPORT.exists() and not BUNDLE.exists()
 smoke=read('installed-smoke.json');assert smoke['state']=='passed'
 units=services();plan=read('plan.json');preserved=read('preservation.json')
 assert all(not (ROOT/name).exists() for name in plan['roots'])
 for name,want in plan['user_docs'].items():assert c.sha(ROOT/name)==want
 index=json.loads((ROOT/'docs/evidence/archive-index.json').read_text());assert len(index['records'])==47
 for row in index['records']:
  compressed=(ROOT/row['archive_path']).read_bytes();assert hashlib.sha256(compressed).hexdigest()==row['archive_sha256']
  raw=gzip.decompress(compressed);assert len(raw)==row['original_bytes'] and hashlib.sha256(raw).hexdigest()==row['original_sha256']
 assert not subprocess.check_output(['git','diff','97c52960358e6d5414fc987dc3861b1e85d997a9','HEAD','--','src'],cwd=ROOT)
 metadata=io.BytesIO();members=[]
 with tarfile.open(fileobj=metadata,mode='w') as bundle:
  for path in sorted(HERE.iterdir()):
   if not path.is_file() or path.suffix not in {'.py','.json','.log','.jsonl'}:continue
   data=path.read_bytes();info=tarfile.TarInfo(path.name);info.mode=0o644;info.mtime=0;info.size=len(data)
   bundle.addfile(info,io.BytesIO(data));members.append(dict(name=path.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 compressed=gzip.compress(metadata.getvalue(),compresslevel=6,mtime=0);c.binary(BUNDLE,compressed)
 with tarfile.open(BUNDLE,'r:gz') as bundle:
  for row in members:
   data=bundle.extractfile(row['name']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 result=dict(schema='tide-compact-repository-evidence-v1',state='retirement_and_validation_completed',
  initial_head='611e8d453160181c97d822674b99527af49548f5',materializer_source='bef26abb2458cfff003c84f376f93bc18a0b4106',
  production_source='97c52960358e6d5414fc987dc3861b1e85d997a9',math_revision='4f5b9f20a4030d68ee66ae2d26e34659a5e37234',
  target_allocated_bytes=200_000_000,repository_allocated_bytes_before=plan['repository_allocated_bytes_before'],
  retirement=read('retirement-result.json'),evidence_compression=read('evidence-compression.json'),
  reviewed_evidence_verification=read('reviewed-evidence-verification.json'),installed_smoke=smoke,
  unit_tests=dict(command='env TORCH_DEVICE_BACKEND_AUTOLOAD=0 .venv-instances/bin/python -m pytest -q tests/test_materialize_record.py',passed=10),
  preservation=dict(commit=preserved['preservation_commit'],clean_tree_commit=preserved['retirement_commit'],
    experimental_worktrees=18,extra_source_config_and_small_records=len(preserved['preserved_files']),
    manifest_path_in_commit='retired-inputs/manifest.json',old_experimental_branch_refs_retained=True),
  maintenance_bundle=dict(path=str(BUNDLE.relative_to(ROOT)),sha256=c.sha(BUNDLE),members=members),
  user_docs=plan['user_docs'],services=units,
  extra_git_repack_executed=False,
  extra_git_repack_note='Repository already meets the target; no extra repack was run after concurrent downstream work was observed. Normal Git commands may pack objects automatically.',
  push=dict(state='pending_after_network_failures',last_confirmed_origin='611e8d453160181c97d822674b99527af49548f5',
    scope='Local Git contains the complete preservation history; no force push or global route/credential change.'),
  temporary_outputs='Retained until this reviewed result is committed; then removed separately.',
  availability=dict(old_artifacts_online=False,old_tensor_replay_promised=False,reviewed_evidence_exact_bytes=True,
     historical_source_in_git=True,downstream_runtime_requires_old_artifacts=False),
  qualification='Original numerical failures, thresholds and measurement identities remain unchanged. Only storage, installed CPU FP32 entry and local recovery were checked.')
 c.atomic(REPORT,result);print(json.dumps(dict(state=result['state'],bundle_bytes=BUNDLE.stat().st_size,services=len(units),preserved_files=len(preserved['preserved_files']))))
def trim():
 record=json.loads(REPORT.read_text());head=c.git('rev-parse','HEAD')
 assert subprocess.check_output(['git','show',head+':'+str(REPORT.relative_to(ROOT))],cwd=ROOT)==REPORT.read_bytes()
 assert subprocess.check_output(['git','show',head+':'+str(BUNDLE.relative_to(ROOT))],cwd=ROOT)==BUNDLE.read_bytes()
 services()
 inventory=[];byte_sum=0
 for name in ['smoke-scratch','record-smoke']:
  directory=HERE/name;assert directory.is_dir() and not directory.is_symlink()
  size=int(subprocess.check_output(['du','-s','-B1',str(directory)]).split()[0]);byte_sum+=size
  inventory.append(dict(path=str(directory.relative_to(ROOT)),allocated_bytes=size,reason='successful isolated validation; result committed'))
  shutil.rmtree(directory)
 # Original metadata is in the byte-verified committed bundle. Keep small source,
 # service/terminal records and a current receipt; discard verbose duplicate plans.
 for row in record['maintenance_bundle']['members']:
  p=HERE/row['name']
  if p.suffix in {'.json','.jsonl'} and p.stat().st_size>100_000:
   assert c.sha(p)==row['sha256'];size=p.stat().st_blocks*512;byte_sum+=size
   inventory.append(dict(path=str(p.relative_to(ROOT)),allocated_bytes=size,sha256=row['sha256'],reason='exact bytes retained in committed maintenance bundle'))
   p.unlink()
 c.sync(HERE)
 receipt=dict(state='retired',committed_result=head,allocated_bytes=byte_sum,files=inventory,finished_utc=datetime.now(timezone.utc).isoformat())
 c.atomic(HERE/'own-retirement.json',receipt)
 print(json.dumps(dict(state='retired',temporary_bytes=byte_sum)))
def audit():
 record=json.loads(REPORT.read_text());sizes={}
 for p in ROOT.iterdir():
  sizes[p.name]=int(subprocess.check_output(['du','-s','-B1',str(p)]).split()[0])
 total=int(subprocess.check_output(['du','-s','-B1',str(ROOT)]).split()[0])
 assert total<200_000_000,total
 assert len(list((ROOT/'artifacts').iterdir()))==1
 assert not any((ROOT/'artifacts').rglob('*.pt')) and not any((ROOT/'artifacts').rglob('*.f32'))
 for name,want in record['user_docs'].items():assert c.sha(ROOT/name)==want
 upstream=subprocess.check_output(['python','scripts/check_upstream.py'],cwd=ROOT,text=True)
 worktrees=c.git('worktree','list','--porcelain');assert worktrees.count('worktree ')==2
 result=dict(state='passed',observed_utc=datetime.now(timezone.utc).isoformat(),repository_allocated_bytes=total,
  target_allocated_bytes=200_000_000,by_top_level_allocated_bytes=sizes,worktrees=worktrees,
  old_artifact_payloads_absent=True,user_docs_unchanged=True,upstream=upstream,
  quota=subprocess.check_output(['quota','-w'],text=True),own_retirement=read('own-retirement.json'),
  observation_boundary='After temporary validation/metadata retirement, before final handoff commit; allocated filesystem blocks, including common Git and private environment.')
 c.atomic(HERE/'final-audit.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ['by_top_level_allocated_bytes','worktrees','own_retirement']},indent=2))
if __name__=='__main__':{'record':record,'trim':trim,'audit':audit}[sys.argv[1]]()
