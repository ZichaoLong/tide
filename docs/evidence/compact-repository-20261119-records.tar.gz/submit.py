"""Finite detached filesystem maintenance and installed-entry verification."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location('j',HERE/'frozen-job.py')
j=importlib.util.module_from_spec(spec);spec.loader.exec_module(j)
kind=sys.argv[1];assert kind in {'preserve','compress','retire','smoke'}
plan=json.loads((HERE/'plan.json').read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
script=HERE/('installed_smoke.py' if kind=='smoke' else 'compact.py')
python=ROOT/'.venv-instances/bin/python' if kind=='smoke' else Path('/usr/bin/python3')
args=[] if kind=='smoke' else [kind]
if kind=='preserve':args+=['--extra-file',str(HERE/'preserve-extra.json')]
if kind=='retire':args+=['--plan-sha',sha(HERE/'plan.json'),'--allow-local-preservation']
unit=f'tide-compact-repository-{kind}-'+('v2' if kind=='retire' else 'v1');timeout=300 if kind=='smoke' else 900
rss=4 if kind=='smoke' else 16;cpus='176 177' if kind=='smoke' else '176 177 178 179 180 181 182 183'
command=[str(python),'-B',str(HERE/'frozen-job.py'),'--status',str(HERE/f'{kind}-status.json'),
 '--source',plan['source'],'--max-rss-gib',str(rss),'--',str(python),'-B',str(script),*args]
argv=['systemd-run','--user',f'--unit={unit}','--service-type=exec','--slice=background.slice',
 '--working-directory=/','--property=KillMode=control-group',f'--property=RuntimeMaxSec={timeout}',
 '--property=TimeoutStopSec=15',f'--property=CPUAffinity={cpus}',f'--property=MemoryMax={rss}G',
 '--property=StandardOutput=append:'+str(HERE/f'{kind}.log'),
 '--property=StandardError=append:'+str(HERE/f'{kind}.log'),*command]
record=dict(state='prepared',unit=unit,source=plan['source'],command=command,launch=argv,
 frozen={p.name:sha(p) for p in [script,HERE/'frozen-job.py',HERE/'plan.json',Path(__file__)]},
 budget=dict(seconds=timeout,rss_gib=rss,cpu_affinity=cpus),scope='CPU only; no NPU')
if kind=='preserve':record['frozen']['preserve-extra.json']=sha(HERE/'preserve-extra.json')
output=HERE/f'{kind}-launch.json';assert not output.exists();j.atomic(output,record)
subprocess.run(argv,check=True)
record['unit_observation']=subprocess.check_output(['systemctl','--user','show',unit,'-p','Slice','-p','ControlGroup','-p','MainPID','-p','ActiveState','-p','SubState'],text=True)
record['state']='submitted';j.atomic(output,record);print(record['unit_observation'])
