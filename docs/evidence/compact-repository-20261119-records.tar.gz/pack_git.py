"""Pack the shared Git object store while retaining every object/ref/reflog."""
import hashlib
import importlib.util
from pathlib import Path
import subprocess
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location('j',HERE/'frozen-job.py')
j=importlib.util.module_from_spec(spec);spec.loader.exec_module(j)
def run(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def size():return int(subprocess.check_output(['du','-s','-B1',str(ROOT/'.git')]).split()[0])
def identities():return sorted(set(run('cat-file','--batch-all-objects','--batch-check=%(objectname)').decode().splitlines()))
def logs():return {str(p.relative_to(ROOT/'.git')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'.git/logs').rglob('*') if p.is_file()}
refs=run('for-each-ref','--format=%(refname) %(objectname)').decode()
before=identities();before_logs=logs();before_bytes=size();start=time.monotonic()
command=['git','-c','pack.threads=4','-c','pack.windowMemory=128m','repack','-a','-d','--keep-unreachable']
subprocess.run(command,cwd=ROOT,check=True)
after=identities()
assert before==after,'Git object identity set changed'
assert refs==run('for-each-ref','--format=%(refname) %(objectname)').decode(),'Git refs changed'
assert before_logs==logs(),'Git reflog content changed'
subprocess.run(['git','fsck','--connectivity-only','--no-dangling'],cwd=ROOT,check=True)
result=dict(state='passed',command=command,elapsed=time.monotonic()-start,
 allocated_bytes_before=before_bytes,allocated_bytes_after=size(),objects=len(before),
 object_ids_sha256=hashlib.sha256(('\n'.join(before)+'\n').encode()).hexdigest(),
 refs=refs,reflogs=before_logs,all_objects_refs_and_reflogs_preserved=True,
 policy='Keep unreachable objects; no prune, reflog expiry, branch deletion or history rewrite.')
j.atomic(HERE/'git-pack-result.json',result);print({k:v for k,v in result.items() if k not in {'refs','reflogs'}})
