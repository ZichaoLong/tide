"""One authorized Git push via the existing command-local proxy entry.

Authentication stays in a temporary mode-0600 runtime file and is never logged.
"""
import base64
import os
from pathlib import Path
import shlex
import subprocess
import tempfile
from urllib.parse import urlsplit, unquote

ROOT=Path(__file__).resolve().parents[2]
value=os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy')
if not value:raise RuntimeError('netpath exec did not provide the existing proxy entry')
proxy=urlsplit(value)
if proxy.hostname not in ('127.0.0.1','localhost') or proxy.scheme!='http':
 raise RuntimeError('expected the existing loopback HTTP CONNECT entry')
with tempfile.TemporaryDirectory(prefix='tide-git-connect-',dir=f'/run/user/{os.getuid()}') as directory:
 path=Path(directory)/'connect.conf'
 auth=base64.b64encode((unquote(proxy.username or '')+':'+unquote(proxy.password or '')).encode()).decode()
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as stream:
  stream.write('NETPATH-CONNECT/1\n'+str(proxy.port)+'\n'+auth+'\n');stream.flush();os.fsync(stream.fileno())
 helper='/home/zlong/.local/share/netpath/components/connect/1/netpath-connect'
 command=f'{shlex.quote(helper)} --config {shlex.quote(str(path))} --fdpass --timeout 20 -- %h %p'
 ssh=['ssh','-F','/run/user/1003/netpath/git-ssh.conf','-o','ProxyCommand='+command,
      '-o','ProxyUseFdpass=yes','-o','HostName=ssh.github.com','-o','HostKeyAlias=github.com',
      '-p','443','-o','StrictHostKeyChecking=yes','-o','BatchMode=yes','-o','ConnectTimeout=25',
      '-o','ServerAliveInterval=20','-o','ServerAliveCountMax=3']
 env=dict(os.environ,GIT_SSH_COMMAND=shlex.join(ssh))
 result=subprocess.run(['git','-c','pack.threads=4','-c','pack.windowMemory=128m',
                        'push','--progress','origin','graph-execution-foundation'],cwd=ROOT,env=env,timeout=150)
 raise SystemExit(result.returncode)
