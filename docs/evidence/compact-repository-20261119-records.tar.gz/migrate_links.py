"""Keep current evidence navigation usable without editing original JSON bytes."""
import importlib.util
import json
from pathlib import Path
import re
import subprocess

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location('compact_links',HERE/'compact.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
index=json.loads((ROOT/'docs/evidence/archive-index.json').read_text())
paths={str(ROOT/r['path']):r for r in index['records']}
changes=[]
pattern=re.compile(r'\[([^\]\n]+)\]\(([^)\n]+)\)')
for name in subprocess.check_output(['git','ls-files','-z','*.md'],cwd=ROOT).decode().split('\0'):
 if not name or name.startswith('math/'):continue
 p=ROOT/name;s=p.read_text();count=[0,0]
 def link(m):
  label,target=m.groups()
  if '://' in target or target.startswith('#'):return m.group(0)
  base,sep,anchor=target.partition('#')
  absolute=(p.parent/base).resolve()
  if str(absolute) in paths:
   count[0]+=1;return f'[{label}]({base}.gz{sep}{anchor})'
  if absolute.is_relative_to(ROOT/'artifacts') and not absolute.is_relative_to(HERE):
   count[1]+=1;return f'{label}（原路径 `{target}`，已退役）'
  return m.group(0)
 changed=pattern.sub(link,s)
 if changed!=s:
  c.binary(p,changed.encode());changes.append(dict(path=name,compressed_links=count[0],retired_links=count[1]))
for base,heading in [
 ('capacity-continuous-20261118','仅复核 JSON 身份，不接触 checkpoint：'),
 ('capacity-execution-20261118','只读核验本页所有引用JSON，不调用模型：'),
 ('training-costs-20261118','只读核验所有被本页引用的原始文件，不运行模型：'),
]:
 p=ROOT/f'docs/evidence/{base}.md';s=p.read_text();start=s.index(heading);end=s.index('\n```',s.index('```sh',start)+5)+4
 replacement=f'''原始 artifacts 已退役，旧逐文件核验依赖不再在线。现在可校验并还原保留于 Git 的审阅证据：

```sh
python scripts/materialize_record.py \\
  --index docs/evidence/archive-index.json \\
  --record docs/evidence/{base}.json \\
  --output /tmp/{base}-review.json
```'''
 c.binary(p,(s[:start]+replacement+s[end:]).encode())
 changes.append(dict(path=str(p.relative_to(ROOT)),replaced_retired_input_verifier=True))
p=ROOT/'docs/computation-and-throughput.md'
if p.exists():
 s=p.read_text();updated=s.replace('同名 JSON','同名 `.json.gz` 审阅证据')
 if updated!=s:c.binary(p,updated.encode())
c.atomic(HERE/'navigation-migration.json',dict(changes=changes,original_json_bytes_unchanged=True))
print(json.dumps(dict(markdown_files=len(changes),compressed_links=sum(r.get('compressed_links',0) for r in changes),retired_links=sum(r.get('retired_links',0) for r in changes))))
