"""Retire a fixed artifact inventory after preserving source and reviewed evidence."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
ARTIFACTS=ROOT/'artifacts'
spec=importlib.util.spec_from_file_location('frozen_job',HERE/'frozen-job.py')
job=importlib.util.module_from_spec(spec);spec.loader.exec_module(job)
atomic=job.atomic
USER_DOCS={
 'docs/tide-learning-lab-TL-REQ-004-handoff.md':'69607cba0a7e87a260929ed5741d996103cef804c51f3fa2c02b3bd7a454a220',
 'docs/tide-learning-lab-TL-REQ-005-handoff.md':'83bec6f6eaa476ae9d7c859fe168333ac2ee564433297f36ab9aa1ef33c38732',
 'docs/tide-learning-lab-TL-REQ-006-handoff.md':'8706f0477c8f31d0c8337e55ba7f8f5b28bb9a455656586fa1585c82ec58b4df',
 'docs/upstream-lh-semantics-discussion-20261113.md':'3118419cb014570395323baf887ffe5a7e797f97049e85eacef26ecb1fd81c07',
}

def now():return datetime.now(timezone.utc).isoformat()
def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(4<<20),b''):h.update(b)
 return h.hexdigest()
def git(*args,env=None,input=None):
 return subprocess.check_output(['git',*map(str,args)],cwd=ROOT,env=env,input=input).decode().strip()
def sync(path):
 fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def binary(path,data):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 fd,tmp=tempfile.mkstemp(dir=path.parent,prefix='.staged-')
 try:
  with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
  os.replace(tmp,path);sync(path.parent)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)
def guard(path):
 s=path.lstat()
 return dict(device=s.st_dev,inode=s.st_ino,size=s.st_size,allocated=s.st_blocks*512,
             mode=s.st_mode,links=s.st_nlink,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def rows():
 result=[]
 for parent,dirs,files in os.walk(ARTIFACTS,followlinks=False):
  p=Path(parent)
  dirs[:]=[d for d in dirs if p/d!=HERE]
  for n in dirs+files:
   f=p/n;s=f.lstat()
   if stat.S_ISDIR(s.st_mode):continue
   assert stat.S_ISREG(s.st_mode) or stat.S_ISLNK(s.st_mode),str(f)
   assert s.st_nlink==1,str(f)
   row=dict(path=str(f.relative_to(ROOT)),stat=guard(f))
   if stat.S_ISLNK(s.st_mode):row['target']=os.readlink(f)
   result.append(row)
 return sorted(result,key=lambda r:r['path'])
def same(row):assert guard(ROOT/row['path'])==row['stat'],row['path']
def worktrees():
 result=[]
 for line in git('worktree','list','--porcelain').splitlines():
  if line.startswith('worktree '):
   p=Path(line[9:]);head=git('-C',p,'rev-parse','HEAD')
   result.append(dict(path=str(p),head=head,tree=git('rev-parse',head+'^{tree}'),
    branch=git('-C',p,'symbolic-ref','HEAD'),status=git('-C',p,'status','--short')))
 return result
def live_refs(roots):
 prefixes=[str(ROOT/p) for p in roots]
 hits=[];restricted=[];checked=0
 def owned(path):return any(path==p or path.startswith(p+'/') for p in prefixes)
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   if proc.stat().st_uid!=os.getuid():continue
   data=(proc/'stat').read_text().rsplit(')',1)[1].split()
   if data[0]=='Z':continue
   for arg in (proc/'cmdline').read_bytes().split(b'\0'):
    if owned(os.fsdecode(arg)):hits.append(dict(pid=int(proc.name),kind='argv',path=os.fsdecode(arg)))
   cwd=os.readlink(proc/'cwd')
   if owned(cwd):hits.append(dict(pid=int(proc.name),kind='cwd',path=cwd))
   for fd in (proc/'fd').iterdir():
    try:
     name=os.readlink(fd)
     if owned(name):hits.append(dict(pid=int(proc.name),kind='fd',path=name))
    except (FileNotFoundError,ProcessLookupError):pass
   for line in (proc/'maps').read_text().splitlines():
    parts=line.split(None,5)
    if len(parts)==6 and owned(parts[-1]):hits.append(dict(pid=int(proc.name),kind='mmap',path=parts[-1]))
   checked+=1
  except PermissionError:
   restricted.append(dict(pid=int(proc.name),name=(proc/'comm').read_text().strip()))
  except (FileNotFoundError,ProcessLookupError):pass
 return dict(observed_utc=now(),hits=hits,restricted=restricted,inspected=checked)

def prepare():
 assert not (HERE/'plan.json').exists()
 wt=worktrees()
 for w in wt:
  if Path(w['path']).is_relative_to(ARTIFACTS/'worktrees'):assert not w['status'],w
 roots=sorted(str(p.relative_to(ROOT)) for p in ARTIFACTS.iterdir() if p!=HERE)
 live=live_refs(roots);assert not live['hits'],live['hits']
 entries=rows();print(f'Hashing {len(entries)} artifact files',flush=True)
 def identity(row):
  if 'target' not in row:row['sha256']=sha(ROOT/row['path'])
  same(row);return row
 with ThreadPoolExecutor(max_workers=8) as pool:entries=list(pool.map(identity,entries))
 records=[]
 for row in entries:
  p=ROOT/row['path']
  if p.name in {'status.json','launch.json'} and 'target' not in row:
   try:
    value=json.loads(p.read_text())
    records.append(dict(path=row['path'],sha256=row['sha256'],value=value))
   except (ValueError,UnicodeError):pass
 assert {p:sha(ROOT/p) for p in USER_DOCS}==USER_DOCS
 plain=sorted((ROOT/'docs/evidence').glob('*.json'));assert len(plain)==47
 evidence=[dict(path=str(p.relative_to(ROOT)),sha256=sha(p),stat=guard(p)) for p in plain]
 plan=dict(schema='tide-compact-repository-plan-v1',state='prepared',created_utc=now(),source=git('rev-parse','HEAD'),
    size_target_bytes=200_000_000,roots=roots,files=entries,worktrees=wt,reviewed_json=evidence,
    user_docs=USER_DOCS,live=live,
    repository_allocated_bytes_before=int(subprocess.check_output(['du','-s','-B1',str(ROOT)]).split()[0]),
    artifacts_allocated_bytes=sum(int(subprocess.check_output(['du','-s','-B1',str(ROOT/p)]).split()[0]) for p in roots),
    authorization='User requested cleanup to <=200 MB after explicit retirement tradeoffs; keep source/math/user documents/downstream/common Git.',
    availability='Retire online old tensor/trace/raw-record content; retain reviewed evidence unchanged in gzip and source snapshots in Git.')
 atomic(HERE/'terminal-and-launch-records.json',dict(records=records,qualification='Historical job states remain unchanged; process availability is a separate observation.'))
 atomic(HERE/'plan.json',plan)
 print(json.dumps(dict(plan_sha256=sha(HERE/'plan.json'),files=len(entries),records=len(records),roots=len(roots),reviewed_json=len(evidence)),indent=2))

def preserve(extra_file):
 plan=json.loads((HERE/'plan.json').read_text());head=git('rev-parse','HEAD')
 assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
 for w in plan['worktrees']:
  if Path(w['path']).is_relative_to(ARTIFACTS/'worktrees'):
   assert git('-C',w['path'],'rev-parse','HEAD')==w['head']
   assert not git('-C',w['path'],'status','--short')
 extras=json.loads(Path(extra_file).read_text())
 # A normalized explicit list is prepared from the dependency audit, never a glob.
 chosen=extras['files'];known={r['path']:r for r in plan['files']}
 for name in chosen:
  assert name in known and 'target' not in known[name];same(known[name])
  assert sha(ROOT/name)==known[name]['sha256']
 index=HERE/'preservation.index';assert not index.exists()
 env=dict(os.environ,GIT_INDEX_FILE=str(index))
 git('read-tree',head,env=env)
 for w in plan['worktrees']:
  p=Path(w['path'])
  if p.is_relative_to(ARTIFACTS/'worktrees'):
   git('read-tree','--prefix=retired-inputs/worktrees/'+p.name+'/',w['tree'],env=env)
 assert all('\n' not in name and '\t' not in name for name in chosen)
 blobs=git('hash-object','-w','--stdin-paths',input=('\n'.join(str(ROOT/name) for name in chosen)+'\n').encode()).splitlines()
 assert len(blobs)==len(chosen)
 preserved=[];index_entries=[]
 for name,blob in zip(chosen,blobs):
  row=known[name]
  dest='retired-inputs/ignored/'+name
  mode='100755' if row['stat']['mode']&stat.S_IXUSR else '100644'
  index_entries.append(f'{mode} {blob}\t{dest}\n')
  preserved.append(dict(original_path=name,path_in_commit=dest,blob=blob,sha256=row['sha256']))
 git('update-index','--index-info',env=env,input=''.join(index_entries).encode())
 # This compact record includes actual historical launch/terminal values, not raw model observations.
 metadata=HERE/'terminal-and-launch-records.json'
 compressed=gzip.compress(metadata.read_bytes(),mtime=0)
 metadata_blob=git('hash-object','-w','--stdin',input=compressed)
 git('update-index','--add','--cacheinfo',f'100644,{metadata_blob},retired-inputs/job-records.json.gz',env=env)
 manifest=dict(original_parent=head,worktrees=plan['worktrees'],preserved_files=preserved,
               job_records_sha256=sha(metadata),plan_sha256=sha(HERE/'plan.json'))
 encoded=(json.dumps(manifest,indent=2)+'\n').encode()
 blob=git('hash-object','-w','--stdin',input=encoded)
 git('update-index','--add','--cacheinfo',f'100644,{blob},retired-inputs/manifest.json',env=env)
 tree=git('write-tree',env=env)
 archive_commit=git('commit-tree',tree,'-p',head,input=b'Preserve retired worktree snapshots and unique experiment source\n')
 for w in plan['worktrees']:
  if Path(w['path']).is_relative_to(ARTIFACTS/'worktrees'):
   assert git('rev-parse',archive_commit+':retired-inputs/worktrees/'+Path(w['path']).name)==w['tree']
 original_tree=git('rev-parse',head+'^{tree}')
 clean_commit=git('commit-tree',original_tree,'-p',archive_commit,input=b'Retire historical snapshots from the working tree after preservation\n')
 assert git('diff','--name-only',head,clean_commit)==''
 git('update-ref','refs/heads/graph-execution-foundation',clean_commit,head)
 index.unlink()
 manifest.update(state='preserved',preservation_commit=archive_commit,retirement_commit=clean_commit)
 atomic(HERE/'preservation.json',manifest)
 print(json.dumps(dict(preservation_commit=archive_commit,retirement_commit=clean_commit,unique_files=len(preserved)),indent=2))

def compress_evidence():
 plan=json.loads((HERE/'plan.json').read_text());out=ROOT/'docs/evidence/archive-index.json'
 assert not out.exists();records=[]
 for row in plan['reviewed_json']:
  p=ROOT/row['path'];same(row);raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
  target=Path(str(p)+'.gz');assert not target.exists()
  data=gzip.compress(raw,compresslevel=6,mtime=0);assert gzip.decompress(data)==raw
  binary(target,data)
  records.append(dict(path=row['path'],archive_path=str(target.relative_to(ROOT)),original_bytes=len(raw),
     original_sha256=row['sha256'],archive_bytes=len(data),archive_sha256=sha(target)))
 index=dict(schema='tide-json-archive-index-v1',created_utc=now(),records=records,
    note='Current reviewed evidence, stored in Git; exact original JSON bytes. Historical artifacts mentioned inside have been retired.')
 atomic(out,index)
 for row in plan['reviewed_json']:same(row);(ROOT/row['path']).unlink()
 sync(out.parent)
 atomic(HERE/'evidence-compression.json',dict(state='completed',index_sha256=sha(out),files=len(records),
  original_bytes=sum(r['original_bytes'] for r in records),archive_bytes=sum(r['archive_bytes'] for r in records)))
 print(json.dumps(json.loads((HERE/'evidence-compression.json').read_text()),indent=2))

def retire(expected):
 assert sha(HERE/'plan.json')==expected
 plan=json.loads((HERE/'plan.json').read_text());preserved=json.loads((HERE/'preservation.json').read_text())
 # The historical tree must be reachable from the pushed current branch before removal.
 assert subprocess.run(['git','merge-base','--is-ancestor',preserved['preservation_commit'],'refs/remotes/origin/graph-execution-foundation'],cwd=ROOT).returncode==0
 assert not (HERE/'retirement-result.json').exists()
 current=rows();assert [(r['path'],r['stat']) for r in current]==[(r['path'],r['stat']) for r in plan['files']]
 for w in plan['worktrees']:
  if Path(w['path']).is_relative_to(ARTIFACTS/'worktrees'):
   assert git('-C',w['path'],'rev-parse','HEAD')==w['head'] and not git('-C',w['path'],'status','--short')
 live=live_refs(plan['roots']);atomic(HERE/'live-pre-retirement.json',live);assert not live['hits'],live['hits']
 removed=[]
 with (HERE/'retirement-receipts.jsonl').open('x') as f:
  for w in plan['worktrees']:
   if Path(w['path']).is_relative_to(ARTIFACTS/'worktrees'):
    f.write(json.dumps(dict(action='git_worktree_remove_intent',**w))+'\n');f.flush();os.fsync(f.fileno())
    subprocess.run(['git','worktree','remove','--force',w['path']],cwd=ROOT,check=True)
    assert git('rev-parse',w['branch'])==w['head'];removed.append(w['path'])
  for name in plan['roots']:
   p=ROOT/name
   f.write(json.dumps(dict(action='retire_artifact_root',path=name))+'\n');f.flush();os.fsync(f.fileno())
   if p.is_dir() and not p.is_symlink():shutil.rmtree(p)
   elif os.path.lexists(p):p.unlink()
  sync(ARTIFACTS)
  f.write(json.dumps(dict(state='completed',utc=now()))+'\n');f.flush();os.fsync(f.fileno())
 for name in plan['roots']:assert not os.path.lexists(ROOT/name)
 for w in plan['worktrees']:
  if not Path(w['path']).is_relative_to(ARTIFACTS/'worktrees') and Path(w['path'])!=ROOT:
   assert git('-C',w['path'],'rev-parse','HEAD')==w['head']
   assert git('-C',w['path'],'status','--short')==w['status']
 assert {p:sha(ROOT/p) for p in USER_DOCS}==USER_DOCS
 result=dict(state='completed',finished_utc=now(),plan_sha256=expected,
    artifact_roots_retired=len(plan['roots']),artifact_files_retired=len(plan['files']),
    artifacts_allocated_bytes_retired=plan['artifacts_allocated_bytes'],worktrees_removed=removed,
    original_worktree_branches_retained=True,downstream_unchanged=True,user_documents_unchanged=True,
    preservation_commit=preserved['preservation_commit'],live=live,
    availability='Old artifacts, local witnesses and original gzip reports are retired. Reviewed evidence and historical source remain in Git.')
 atomic(HERE/'retirement-result.json',result);print(json.dumps(result,indent=2))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','preserve','compress','retire'])
 p.add_argument('--extra-file');p.add_argument('--plan-sha');a=p.parse_args()
 if a.action=='prepare':prepare()
 elif a.action=='preserve':preserve(a.extra_file)
 elif a.action=='compress':compress_evidence()
 else:retire(a.plan_sha)
